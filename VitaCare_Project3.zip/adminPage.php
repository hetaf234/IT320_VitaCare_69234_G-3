<?php
session_start();

if (!isset($_SESSION['vitamins']) || count($_SESSION['vitamins']) === 0) {  
   $_SESSION['vitamins'] = [
        ['name' => 'Vitamin A', 'dose' => '900 mg'],
        ['name' => 'Vitamin E', 'dose' => '15 mg'],
        ['name' => 'Vitamin D', 'dose' => '1000 mg'],
        ['name' => 'Vitamin C', 'dose' => '500 mg'],
        ['name' => 'Vitamin B12', 'dose' => '250 mg'],
    ];
}

/* Delete */
if (isset($_POST['delete_index'])) {
    $index = (int) $_POST['delete_index'];

    if (isset($_SESSION['vitamins'][$index])) {
        $name = $_SESSION['vitamins'][$index]['name']; 
        array_splice($_SESSION['vitamins'], $index, 1); 
    }

    header("Location: adminPage.php?success=deleted&name=" . urlencode($name));
    exit();
}

$vitamins = $_SESSION['vitamins'];
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin - VitaCare</title>
<link rel="stylesheet" href="adminPage.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
    button {
        font-family: Georgia, "Times New Roman", serif;
    }
    
    /* Delete Modal */
    .delete-modal {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.35);
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }
    
    .delete-modal.show {
        display: flex;
    }
    
    .delete-modal-box {
        background: #fff;
        width: 420px;
        max-width: 90%;
        padding: 25px;
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    
    .delete-modal-box h2 {
        margin: 0 0 18px;
        font-size: 24px;
        font-family: Georgia, "Times New Roman", serif;
        color: #333;
    }
    
    .delete-modal-box p {
        margin: 0 0 20px;
        font-size: 16px;
        font-family: Georgia, "Times New Roman", serif;
        color: #555;
    }
    
    .delete-modal-actions {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        margin-top: 20px;
    }
    
    .modal-delete-btn {
        background: #f8e0e0;
        color: #c62828;
        border: none;
        border-radius: 8px;
        padding: 10px 16px;
        font-size: 15px;
        cursor: pointer;
        font-family: Georgia, "Times New Roman", serif;
    }
    
    .modal-delete-btn:hover {
        background: #f8c6c6;
    }
    
    .modal-cancel-btn {
        background: #eeeeee;
        color: #222;
        border: none;
        border-radius: 8px;
        padding: 10px 16px;
        font-size: 15px;
        cursor: pointer;
        font-family: Georgia, "Times New Roman", serif;
    }
    
    .modal-cancel-btn:hover {
        background: #dddddd;
    }
    
    .icon-btn {
        width: 40px;
        height: 40px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
    }
    
    .icon-btn.edit {
        background: #d4e3ff;
    }
    
    .icon-btn.edit:hover {
        background: #afc7fa;
    }
    
    .icon-btn.delete {
        background: #f8e0e0;
    }
    
    .icon-btn.delete:hover {
        background: #f8c6c6;
    }
    
    .icon-btn.delete i {
        color: #c62828;
    }
    
    /* Message Box */
    .message-box {
        display: none;
        padding: 12px;
        margin-bottom: 15px;
        border-radius: 8px;
        font-size: 14px;
    }
    
    .message-error {
        background: #f8e0e0;
        color: #7a2d2d;
    }
    
    .message-success {
        background: #dff4df;
        color: #246024;
    }
    
    /* Add Vitamin Button - مثل customer dashboard */
    .add-btn {
        background: #d4e3ff;
        padding: 10px 16px;
        border-radius: 8px;
        font-size: 16px;
        border: 2px solid #d4e3ff;
        text-decoration: none;
        color: #1a1a1a;
        font-family: Georgia, "Times New Roman", serif;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    
    .add-btn:hover {
        background: #afc7fa;
    }
    
    /* Logout Button - مثل customer dashboard */
    .logout-btn {
        border: none;
        cursor: pointer;
        background-color: #f8e0e0;
        width: 30%;
        color: #c62828;
        font-family: Georgia, "Times New Roman", serif;
        padding: 12px;
        border-radius: 8px;
        font-size: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
    
    .logout-btn:hover {
        background-color: #f8c6c6;
    }
    
    /* Success Banner */
    .success-banner {
        background: #dff4df;
        color: #246024;
        padding: 12px 20px;
        margin: 20px auto;
        border-radius: 8px;
        text-align: center;
        width: 80%;
        font-family: Georgia, "Times New Roman", serif;
    }
    
    /* admin container */
    .admin-container {
        width: 90%;
        max-width: 1200px;
        margin: 40px auto;
    }
    
    .add-btn-container {
        margin-bottom: 20px;
        text-align: left;
    }
    
    .admin-box {
        background: #ffffff;
        border: 1px solid #eee;
        border-radius: 15px;
        padding: 30px;
    }
    
    .vitamin-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px;
        border-bottom: 1px solid #eee;
        font-family: Georgia, "Times New Roman", serif;
    }
    
    .vitamin-row:last-child {
        border-bottom: none;
    }
    
    .actions {
        display: flex;
        gap: 10px;
    }
</style>
</head>

<body>

<div class="navbar">
    <div class="logo">
        <img src="image/logo.PNG" alt="VitaCare Logo">
    </div>
    <div class="nav-title">Admin Dashboard</div>
    <a href="#" class="user-menu">
        <img src="image/icon.png" alt="User" class="user-img">
        <span>Admin</span>
    </a>
</div>

<?php if (isset($_GET['success']) && $_GET['success'] === 'deleted'): ?>
    <div class="success-banner" id="successBanner">
        <?php echo htmlspecialchars($_GET['name']); ?> has been deleted successfully.
    </div>
<?php endif; ?>

<div class="admin-container">
    <div class="add-btn-container">
        <a href="add-vitamin.php" class="add-btn">
            <i class="fa-solid fa-plus"></i> Add Vitamin
        </a>
    </div>

    <div class="admin-box">
        <?php if (empty($vitamins)): ?>
            <p style="text-align:center; color:#888;">No vitamins added yet.</p>
        <?php else: ?>
            <?php foreach ($vitamins as $i => $v): ?>
                <div class="vitamin-row">
                    <span><?php echo htmlspecialchars($v['name']); ?> - <?php echo htmlspecialchars($v['dose']); ?></span>
                    <div class="actions">
                        <a href="edit-vitamin.php?index=<?php echo $i; ?>" class="icon-btn edit">
                            <i class="fa-solid fa-pen"></i>
                        </a>
                        <button type="button" class="icon-btn delete open-delete-modal" data-index="<?php echo $i; ?>" data-name="<?php echo htmlspecialchars($v['name']); ?>">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div style="margin-top: 40px; text-align: left;">
        <button id="logoutBtn" class="logout-btn">
            <i class="fa-solid fa-sign-out-alt"></i> Log Out
        </button>
        <div id="messageBox" class="message-box" style="margin-top: 15px;"></div>
    </div>
</div>

<footer class="footer">
    <div class="footer-line"></div>
    <div class="footer-inner">
        <p class="contact-title">Contact Us:</p>
        <div class="contact-row">
            <span class="contact-item">
                <img src="image/email.png" alt="Email" class="icon">
                <a href="mailto:VitaCare@gmail.com">VitaCare@gmail.com</a>
            </span>
            <span class="contact-item">
                <img src="image/phone.png" alt="Phone" class="icon">
                <a href="tel:+966556678127">+966 556678127</a>
            </span>
        </div>
        <p class="copyright">
            &copy; 2026 <a href="index.php">VitaCare</a>. All rights reserved.
        </p>
    </div>
</footer>

<!-- DELETE MODAL -->
<div id="deleteModal" class="delete-modal">
    <div class="delete-modal-box">
        <h2>Delete Vitamin</h2>
        <p id="deleteVitaminName">Are you sure you want to delete this vitamin?</p>
        <div class="delete-modal-actions">
            <button type="button" id="confirmDeleteBtn" class="modal-delete-btn">Delete</button>
            <button type="button" id="cancelDeleteBtn" class="modal-cancel-btn">Cancel</button>
        </div>
    </div>
</div>

<!-- LOGOUT MODAL -->
<div id="logoutModal" class="delete-modal">
    <div class="delete-modal-box">
        <h2>Confirm Logout</h2>
        <p>Are you sure you want to log out of your account?</p>
        <div class="delete-modal-actions">
            <button type="button" id="confirmLogoutBtn" class="modal-delete-btn">Log Out</button>
            <button type="button" id="cancelLogoutBtn" class="modal-cancel-btn">Cancel</button>
        </div>
    </div>
</div>

<script>
// ==================== LOGOUT FUNCTIONALITY ====================
const logoutBtn = document.getElementById("logoutBtn");
const messageBox = document.getElementById("messageBox");
const logoutModal = document.getElementById("logoutModal");
const confirmLogoutBtn = document.getElementById("confirmLogoutBtn");
const cancelLogoutBtn = document.getElementById("cancelLogoutBtn");

function performLogout() {
    if (logoutModal) {
        logoutModal.classList.remove("show");
    }
    
    if (messageBox) {
        messageBox.textContent = "Logout successful. Redirecting...";
        messageBox.className = "message-box message-success";
        messageBox.style.display = "block";
    }
    
    setTimeout(function() { 
        window.location.href = "index.php"; 
    }, 1200);
}

if (logoutBtn) {
    logoutBtn.addEventListener("click", function(e) {
        e.preventDefault();
        if (logoutModal) {
            logoutModal.classList.add("show");
        }
    });
}

if (confirmLogoutBtn) {
    confirmLogoutBtn.addEventListener("click", function() {
        performLogout();
    });
}

if (cancelLogoutBtn) {
    cancelLogoutBtn.addEventListener("click", function() {
        if (logoutModal) {
            logoutModal.classList.remove("show");
        }
    });
}

// ==================== DELETE VITAMIN FUNCTIONALITY ====================
let deleteIndex = null;
const deleteModal = document.getElementById("deleteModal");
const confirmDeleteBtn = document.getElementById("confirmDeleteBtn");
const cancelDeleteBtn = document.getElementById("cancelDeleteBtn");
const deleteVitaminNameSpan = document.getElementById("deleteVitaminName");

// فتح موديل الحذف
document.querySelectorAll(".open-delete-modal").forEach(btn => {
    btn.addEventListener("click", function() {
        deleteIndex = this.getAttribute("data-index");
        const vitaminName = this.getAttribute("data-name");
        deleteVitaminNameSpan.innerHTML = `Are you sure you want to delete "<strong>${vitaminName}</strong>"?`;
        deleteModal.classList.add("show");
    });
});

// تأكيد الحذف
if (confirmDeleteBtn) {
    confirmDeleteBtn.addEventListener("click", function() {
        if (deleteIndex !== null) {
            const form = document.createElement("form");
            form.method = "POST";
            form.action = "";
            const input = document.createElement("input");
            input.type = "hidden";
            input.name = "delete_index";
            input.value = deleteIndex;
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
    });
}

// إلغاء الحذف
if (cancelDeleteBtn) {
    cancelDeleteBtn.addEventListener("click", function() {
        deleteModal.classList.remove("show");
        deleteIndex = null;
    });
}

// إغلاق الموديل عند الضغط خارج المحتوى
window.addEventListener("click", function(e) {
    if (e.target === deleteModal) {
        deleteModal.classList.remove("show");
        deleteIndex = null;
    }
    if (e.target === logoutModal) {
        logoutModal.classList.remove("show");
    }
});

// إخفاء رسالة النجاح بعد 3 ثواني
const banner = document.getElementById("successBanner");
if (banner) {
    setTimeout(() => {
        banner.style.display = "none";
    }, 3000);
}

// إخفاء رسالة الـ messageBox في البداية
if (messageBox) {
    messageBox.style.display = "none";
}
</script>

</body>
</html>