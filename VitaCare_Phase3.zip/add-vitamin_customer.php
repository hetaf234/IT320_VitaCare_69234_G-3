<?php
session_start();

$profilePage = "profilepage.php";
$userName = $_SESSION['user_name'] ?? $_SESSION['name'] ?? "User";
/* =========================
Vitamins from Admin Page
========================= */
if (!isset($_SESSION['vitamins'])) {
$_SESSION['vitamins'] = [
['name' => 'Vitamin D', 'dose' => '1000 mg'],
['name' => 'Vitamin C', 'dose' => '500 mg'],
['name' => 'Vitamin B12', 'dose' => '250 mg'],
['name' => 'Vitamin A', 'dose' => '900 mg'],
['name' => 'Vitamin E', 'dose' => '15 mg'],
];
}

if (!isset($_SESSION['userVitamins'])) {
$_SESSION['userVitamins'] = [];
}

$adminVitamins = $_SESSION['vitamins'];
$successMessage = "";
$errorMessage = "";
$redirectToView = false;

/* =========================
Handle Form Submit
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$selectedVitamin = trim($_POST['selectedVitamin'] ?? '');
$intakeTime = trim($_POST['intakeTime'] ?? '');
$numberOfPills = trim($_POST['numberOfPills'] ?? '');
$selectedDays = $_POST['days'] ?? [];

if (
$selectedVitamin === '' ||
$intakeTime === '' ||
$numberOfPills === '' ||
empty($selectedDays)
) {
$errorMessage = "Please complete all fields before confirming.";
} elseif (!is_numeric($numberOfPills) || (int)$numberOfPills <= 0) {
$errorMessage = "Number of Pills must be greater than 0.";
} else {
$foundVitamin = null;

foreach ($adminVitamins as $vitamin) {
if (strcasecmp($vitamin['name'], $selectedVitamin) === 0) {
$foundVitamin = $vitamin;
break;
}
}

if (!$foundVitamin) {
$errorMessage = "The selected vitamin is not available.";
} else {
$_SESSION['userVitamins'][] = [
'name' => $foundVitamin['name'],
'dose' => $foundVitamin['dose'],
'time' => $intakeTime,
'numberOfPills' => (int)$numberOfPills,
'days' => array_values($selectedDays),
'status' => 'Not Taken'
];

$successMessage = $foundVitamin['name'] . " has been added successfully. Redirecting to View User Schedule...";
$redirectToView = true;
}
}
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Add Vitamin - VitaCare</title>
<link rel="stylesheet" href="add-vitamin_customer.css">
</head>

<body>

<div class="navbar">
<div class="logo">
<img src="image/logo.PNG" alt="VitaCare Logo">
</div>

<div class="nav-title">
Add Vitamin
</div>

     
<a href="<?php echo htmlspecialchars($profilePage); ?>" class="user-menu">
<img src="image/icon.png" alt="User" class="user-img">
<span><?php echo htmlspecialchars($userName); ?></span>
</a>
</div>

<div class="breadcrumb">
  <a href="customer-dashboard.php" class="back-link">My Vitamins</a>
  <span class="breadcrumb-separator">/</span>
  <span class="current-page-link">Add Vitamin</span>
</div>
<main class="main">
<div class="card">

<h1>Add Vitamin</h1>
<p class="page-subtitle">Add a vitamin intake to your schedule</p>

<?php if ($errorMessage): ?>
<div class="error-message">
<?php echo htmlspecialchars($errorMessage); ?>
</div>
<?php endif; ?>

<?php if ($successMessage): ?>
<div id="successMessage" class="success-message">
<?php echo htmlspecialchars($successMessage); ?>
</div>
<?php else: ?>
<div id="successMessage" class="success-message hidden"></div>
<?php endif; ?>

<section id="searchSection">
<label for="searchInput" class="section-label">Search by vitamin name</label>

<div class="search-wrapper">
<div class="search-box">
<input type="text" id="searchInput" placeholder="Enter vitamin name" autocomplete="off">
<button class="btn search-btn" id="searchBtn" type="button">Search</button>
</div>

<div id="resultsBox" class="results-box hidden"></div>
</div>
</section>

<section id="detailsSection" class="hidden details-section">
<h2 id="selectedVitaminTitle">Selected Vitamin</h2>

<form method="POST" id="vitaminForm" class="vitamin-form">
<input type="hidden" name="selectedVitamin" id="selectedVitamin">

<label for="intakeTime">Intake Time</label>
<input type="time" id="intakeTime" name="intakeTime" required>

<label>Frequency (Select days)</label>
<div class="days-container">
<label><input type="checkbox" name="days[]" value="Sunday"> Sunday</label>
<label><input type="checkbox" name="days[]" value="Monday"> Monday</label>
<label><input type="checkbox" name="days[]" value="Tuesday"> Tuesday</label>
<label><input type="checkbox" name="days[]" value="Wednesday"> Wednesday</label>
<label><input type="checkbox" name="days[]" value="Thursday"> Thursday</label>
<label><input type="checkbox" name="days[]" value="Friday"> Friday</label>
<label><input type="checkbox" name="days[]" value="Saturday"> Saturday</label>
</div>

<label for="numberOfPills">Number of Pills</label>
<input type="number" id="numberOfPills" name="numberOfPills" placeholder="Enter number of pills" min="1" step="1" required>

<button type="submit" class="btn confirm-btn">Confirm</button>
</form>
</section>

</div>
</main>

<footer class="footer">
<div class="footer-inner">
<div class="footer-left">
<strong>Contact Us:</strong>
</div>

<div class="footer-mid">
<span class="contact-item">
<img class="icon" src="image/email.png" alt="Email icon">
<a class="footer-link" href="mailto:VitaCare@gmail.com">VitaCare@gmail.com</a>
</span>

<span class="contact-item">
<img class="icon" src="image/phone.png" alt="Phone icon">
<a class="footer-link" href="tel:+966556678127">+966 556678127</a>
</span>
</div>

<div class="footer-bottom">
&copy; 2026 <a class="footer-link" href="index.php">VitaCare</a>. All rights reserved.
</div>
</div>
</footer>

<script>
let selectedVitamin = "";
const vitaminDatabase = <?php echo json_encode($adminVitamins, JSON_UNESCAPED_UNICODE); ?>;

const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");
const resultsBox = document.getElementById("resultsBox");
const detailsSection = document.getElementById("detailsSection");
const selectedVitaminTitle = document.getElementById("selectedVitaminTitle");
const vitaminForm = document.getElementById("vitaminForm");
const hiddenSelectedVitamin = document.getElementById("selectedVitamin");

searchInput.addEventListener("input", showSuggestions);
searchBtn.addEventListener("click", showSuggestions);

function showSuggestions() {
const query = searchInput.value.trim().toLowerCase();
resultsBox.innerHTML = "";

if (query === "") {
resultsBox.classList.add("hidden");
detailsSection.classList.add("hidden");
return;
}

const matches = vitaminDatabase.filter(vitamin =>
vitamin.name.toLowerCase().startsWith(query)
);

if (matches.length === 0) {
resultsBox.classList.remove("hidden");
resultsBox.innerHTML = '<div class="no-result">No matching vitamins found.</div>';
detailsSection.classList.add("hidden");
return;
}

matches.forEach(vitamin => {
const item = document.createElement("div");
item.className = "suggestion-item";
item.textContent = vitamin.name + " - " + vitamin.dose;

item.addEventListener("click", function () {
searchInput.value = vitamin.name;
selectedVitamin = vitamin.name;
hiddenSelectedVitamin.value = vitamin.name;
resultsBox.classList.add("hidden");
selectedVitaminTitle.textContent = "Selected Vitamin: " + vitamin.name + " (" + vitamin.dose + ")";
detailsSection.classList.remove("hidden");
});

resultsBox.appendChild(item);
});

resultsBox.classList.remove("hidden");
}

document.addEventListener("click", function (e) {
if (!e.target.closest(".search-wrapper")) {
resultsBox.classList.add("hidden");
}
});

vitaminForm.addEventListener("submit", function (e) {
const intakeTime = document.getElementById("intakeTime").value;
const numberOfPills = document.getElementById("numberOfPills").value;
const selectedDays = document.querySelectorAll('input[name="days[]"]:checked');

if (!selectedVitamin || !intakeTime || !numberOfPills || selectedDays.length === 0) {
e.preventDefault();
alert("Please complete all fields before confirming.");
return;
}

const pillsValue = Number(numberOfPills);

if (isNaN(pillsValue) || pillsValue <= 0) {
e.preventDefault();
alert("Number of Pills must be greater than 0.");
}
});
</script>

<?php if ($redirectToView): ?>
<script>
setTimeout(function () {
window.location.href = "customer-dashboard.php";
}, 2000);
</script>
<?php endif; ?>

</body>
</html>