<?php
session_start();

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $dose = trim($_POST['dose'] ?? '');

    // VALIDATION
    if ($name === '' || $dose === '') {
        $error = "Please enter valid vitamin information.";
    }
    elseif (!preg_match("/^[a-zA-Z0-9\s]+$/", $name)) {
    $error = "Vitamin name must contain letters and numbers only.";
}
    elseif (!preg_match("/^[0-9]+$/", $dose)) {
        $error = "Dose must contain numbers only.";
    }
    elseif ((int)$dose <= 0) {
        $error = "Dose must be greater than 0.";
    }
    else {
        $doseFormatted = $dose . " mg";

        $exists = false;
foreach ($_SESSION['vitamins'] as $v) {
    if (
        strtolower($v['name']) === strtolower($name) &&
        $v['dose'] === $doseFormatted
    ) {
        $exists = true;
        break;
    }
}

        if ($exists) {
            $error = "This vitamin with the same dose already exists.";
        } else {
            $_SESSION['vitamins'][] = [
                'name' => $name,
                'dose' => $doseFormatted
            ];
$success = "Vitamin has been added successfully. Redirecting to Admin Dashboard...";        }
    }
}


?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Add Vitamin</title>
<link rel="stylesheet" href="adminPage.css">

<style>
.error-box {
  background: #fbe4e4;
  color: #a94442;
  padding: 14px;
  border-radius: 12px;
  margin-bottom: 15px;
  font-size: 14px;
}
</style>

</head>

<body>

    
<div class="navbar">
  <div class="logo">
    <img src="image/logo.PNG" alt="VitaCare Logo">
  </div>

  <div class="nav-title">
    Add New Vitamin 
  </div>

  <a href="#" class="user-menu">
    <img src="image/icon.png" alt="User" class="user-img">
    <span>Admin</span>
  </a>
</div>

<!-- breadcrumb -->
<nav class="breadcrumbs">
  <a href="adminPage.php">Admin Dashboard</a> <span>/</span> Add New Vitamin
</nav>

<div class="add-container">
  <div class="card">
  
    
    <?php if (!empty($success)): ?>
  <div class="success-banner" id="successBanner">
    <?php echo $success; ?>
  </div>

  <script>
    setTimeout(() => {
      window.location.href = "adminPage.php";
    }, 2000);
  </script>
<?php endif; ?>
  
    <?php if (!empty($error)): ?>
      <div class="error-box">
        <?php echo htmlspecialchars($error); ?>
      </div>
    <?php endif; ?>

    <form method="POST" class="form-box" novalidate>
       <fieldset style="border: 2px solid #bdbdbd; padding: 30px 25px 35px; width: 350px; margin: 0 auto;">
     <legend> Add New Vitamin </legend>
      <!-- NAME -->
    
      
       <label for="name">Vitamin Name:</label>
          <input id="name" name="name" type="text" placeholder="Vitamin name" value= "<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>"
                 required>

      <!-- DOSE -->
      <div class="dose-wrapper">
    
         <label for="dose">Dose:</label>
          <input id="dose" name="dose" type="numeric" placeholder="Dose in mg" 
                 value="<?php echo htmlspecialchars($_POST['dose'] ?? ''); ?>"
                 required>
        
        
       
      </div>

      <!-- BUTTONS -->
      <button type="submit" class="btn">Add</button>
<button type="button" class="btn" onclick="window.location.href='adminPage.php'">
  Cancel
</button>
      </fieldset> 
    </form>
  </div>
</div>

<footer class="footer">
  <div class="footer-line"></div>
  <div class="footer-inner">
    <p class="contact-title">Contact Us:</p>
    <div class="contact-row">
      <span class="contact-item">
        <img src="image/email.png" alt="Email" class="icon">
        <a href="mailto:VitaCare@gmail.com">VitaCare@gmail.com</a>
      </span>
      <span class="contact-item">
        <img src="image/phone.png" alt="Phone" class="icon">
        <a href="tel:+966556678127">+966 556678127</a>
      </span>
    </div>
    <p class="copyright">
      &copy; 2026 <a href="index.php">VitaCare</a>. All rights reserved.
    </p>
  </div>
</footer>

</body>
</html>