document.addEventListener('DOMContentLoaded', function() {
    const logoutBtn = document.getElementById("logoutBtn");
    const messageBox = document.getElementById("messageBox");
    const logoutModal = document.getElementById("logoutModal");
    const confirmLogoutBtn = document.getElementById("confirmLogoutBtn");
    const cancelLogoutModalBtn = document.getElementById("cancelLogoutModalBtn");

    function performLogout() {
        if (logoutModal) {
            logoutModal.classList.remove("show");
        }
        
        if (messageBox) {
            messageBox.textContent = "Logout successful. Redirecting...";
            messageBox.className = "message-box message-success";
            messageBox.style.display = "block";
        }
        
        fetch('logout.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=logout'
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            setTimeout(function() { 
                window.location.href = "index.php"; 
            }, 1200);
        })
        .catch(function(error) {
            setTimeout(function() { 
                window.location.href = "index.php"; 
            }, 1200);
        });
    }

    if (logoutBtn) {
        logoutBtn.addEventListener("click", function(e) {
            e.preventDefault();
            if (logoutModal) {
                logoutModal.classList.add("show");
            }
        });
    }

    if (confirmLogoutBtn) {
        confirmLogoutBtn.addEventListener("click", function() {
            performLogout();
        });
    }

    if (cancelLogoutModalBtn) {
        cancelLogoutModalBtn.addEventListener("click", function() {
            if (logoutModal) {
                logoutModal.classList.remove("show");
            }
        });
    }

    window.onclick = function(event) {
        if (event.target === logoutModal) {
            logoutModal.classList.remove("show");
        }
    }

    if (messageBox) {
        messageBox.style.display = "none";
    }
});