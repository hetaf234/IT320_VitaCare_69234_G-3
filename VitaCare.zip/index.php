<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" >
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>VitaCare - Home Page</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <main class="main">
    <section class="card">
      <h1>VitaCare</h1>

      <div class="logo">
        <img src="image/logo.png" alt="VitaCare logo">
      </div>

     <button class="btn btn-wide" type="button" onclick="location.href='login.php'">
		Login
	</button>

      <p class="hint">
        New here?
        <a class="link-underline" href="signup.php">Sign up</a>
      </p>
    </section>
  </main>

  <footer class="footer">
    <div class="footer-inner">
      <div class="footer-left">
        <strong>Contact Us:</strong>
      </div>

      <div class="footer-mid">
        <span class="contact-item">
          <img class="icon" src="image/email.png" alt="Email icon" />
          <a class="footer-link" href="mailto:VitaCare@gmail.com">VitaCare@gmail.com</a>
        </span>

        <span class="contact-item">
           <img class="icon" src="image/phone.png" alt="Phone icon" />
          <a class="footer-link" href="tel:+966556678127">+966 556678127</a>
        </span>
      </div>

      <div class="footer-bottom">
        &copy; 2026 <a class="footer-link" href="index.html">VitaCare</a>. All rights reserved.
      </div>
    </div>
  </footer>

</body>
</html>   
