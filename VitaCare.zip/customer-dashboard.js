const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

let vitamins = Array.isArray(INITIAL_VITAMINS) ? INITIAL_VITAMINS : [];
let taken = Array.isArray(INITIAL_TAKEN) ? INITIAL_TAKEN : [];

function getTakenKey(index, day) {
  return `${index}_${day}`;
}

function showModalMessage(text, type = "error") {
  const box = document.getElementById("modalMessage");
  if (!box) return;

  box.textContent = text;
  box.className = `message-box message-${type}`;
  box.style.display = "block";
}

function showMessage(text, type = "success") {
  const box = document.getElementById("messageBox");
  if (!box) return;

  box.textContent = text;
  box.className = `message-box message-${type}`;
  box.style.display = "block";

  setTimeout(() => {
    box.style.display = "none";
  }, 3000);
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text ?? "";
  return div.innerHTML;
}

async function postAction(data) {
  const response = await fetch("customer-dashboard.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: new URLSearchParams(data).toString()
  });

  return response.json();
}

function render() {
  const row = document.getElementById("tableRow");
  if (!row) return;

  row.innerHTML = "";

  DAYS.forEach(day => {
    const td = document.createElement("td");
    const col = document.createElement("div");
    col.className = "day-column";

    const dayVitamins = vitamins
      .map((v, i) => ({ ...v, index: i }))
      .filter(v => Array.isArray(v.days) && v.days.includes(day));

    if (dayVitamins.length === 0) {
      col.innerHTML = `<div class="no-vitamin">No vitamins</div>`;
    } else {
      dayVitamins.forEach(v => {
        const isTaken = taken.includes(getTakenKey(v.index, day));

        const item = document.createElement("div");
        item.className = "vitamin-item";

        item.innerHTML = `
          <div class="vitamin-item-name">${escapeHtml(v.name)}</div>
          <div class="vitamin-detail">Time: ${escapeHtml(v.time)}</div>
          <div class="vitamin-detail">Pills: ${escapeHtml(String(v.numberOfPills))}</div>
          <div class="vitamin-detail">Dose: ${escapeHtml(v.dose ?? "")}</div>

          <div class="vitamin-detail">
            Status:
            <span class="${isTaken ? "status-taken" : "status-not-taken"}">
              ${isTaken ? "Taken" : "Not Taken"}
            </span>
          </div>

          <div class="item-actions">
            <button class="icon-btn edit-icon-btn" type="button" onclick="openEditModal(${v.index})" title="Edit">
              <i class="fa fa-pen"></i>
            </button>

            <button class="icon-btn delete-icon-btn" type="button" onclick="openDeleteModal(${v.index})" title="Delete">
              <i class="fa fa-trash"></i>
            </button>

            <button class="icon-btn taken-icon-btn" type="button" onclick="toggleTaken(${v.index}, '${day}')" title="Taken">
              <i class="fa fa-check"></i>
            </button>
          </div>
        `;

        col.appendChild(item);
      });
    }

    td.appendChild(col);
    row.appendChild(td);
  });

  updateStreak();
}

function openEditModal(index) {
  const vitamin = vitamins[index];
  if (!vitamin) return;

  document.getElementById("editIndex").value = index;
  document.getElementById("editName").value = vitamin.name || "";
  document.getElementById("editTime").value = vitamin.time || "";
  document.getElementById("editPills").value = vitamin.numberOfPills || "";

  const modalMessage = document.getElementById("modalMessage");
  if (modalMessage) {
    modalMessage.style.display = "none";
    modalMessage.textContent = "";
  }

  document.getElementById("editModal").classList.add("show");
}

function closeEditModal() {
  document.getElementById("editModal").classList.remove("show");

  const modalMessage = document.getElementById("modalMessage");
  if (modalMessage) {
    modalMessage.style.display = "none";
    modalMessage.textContent = "";
  }

  document.getElementById("editIndex").value = "";
  document.getElementById("editName").value = "";
  document.getElementById("editTime").value = "";
  document.getElementById("editPills").value = "";
}
async function saveEdit() {
  const index = parseInt(document.getElementById("editIndex").value, 10);
  const newName = document.getElementById("editName").value.trim();
  const newTime = document.getElementById("editTime").value.trim();
  const newPills = document.getElementById("editPills").value.trim();

  if (newName === "" || newTime === "" || newPills === "" || parseInt(newPills, 10) <= 0) {
    showModalMessage("Please enter valid vitamin information.");
    return;
  }

  const hasLetter = /[A-Za-z]/;

  if (!hasLetter.test(newName)) {
    showModalMessage("Vitamin name cannot be numbers only.");
    return;
  }

  const result = await postAction({
    action: "edit",
    index,
    name: newName,
    time: newTime,
    numberOfPills: newPills
  });

  if (!result.success) {
    showModalMessage(result.message || "Failed to update vitamin.");
    return;
  }

  vitamins = result.vitamins || [];
  taken = result.taken || [];
  closeEditModal();
  showMessage("Vitamin updated successfully.", "success");
  render();
}

function openDeleteModal(index) {
  document.getElementById("deleteIndex").value = index;
  document.getElementById("deleteModal").classList.add("show");
}

function closeDeleteModal() {
  document.getElementById("deleteModal").classList.remove("show");
  document.getElementById("deleteIndex").value = "";
}

async function confirmDelete() {
  const index = parseInt(document.getElementById("deleteIndex").value, 10);

  const result = await postAction({
    action: "delete",
    index
  });

  if (!result.success) {
    showMessage(result.message || "Failed to delete vitamin.", "error");
    return;
  }

  vitamins = result.vitamins || [];
  taken = result.taken || [];
  closeDeleteModal();
  showMessage("Vitamin deleted successfully.", "success");
  render();
}

async function toggleTaken(index, day) {
  const result = await postAction({
    action: "toggleTaken",
    index,
    day
  });

  if (!result.success) {
    showMessage(result.message || "Failed to update status.", "error");
    return;
  }

  vitamins = result.vitamins || [];
  taken = result.taken || [];
  render();
}

function updateStreak() {
  const streakNumber = document.getElementById("streakNumber");
  if (!streakNumber) return;

  let completedDays = 0;

  DAYS.forEach(day => {
    const dayVitaminIndexes = vitamins
      .map((v, i) => ({ ...v, index: i }))
      .filter(v => Array.isArray(v.days) && v.days.includes(day))
      .map(v => v.index);

    if (dayVitaminIndexes.length === 0) {
      return;
    }

    const allTakenForDay = dayVitaminIndexes.every(index =>
      taken.includes(getTakenKey(index, day))
    );

    if (allTakenForDay) {
      completedDays++;
    }
  });

  streakNumber.textContent = completedDays;
}

window.onclick = function (event) {
  const editModal = document.getElementById("editModal");
  const deleteModal = document.getElementById("deleteModal");

  if (event.target === editModal) {
    closeEditModal();
  }

  if (event.target === deleteModal) {
    closeDeleteModal();
  }
};

render();